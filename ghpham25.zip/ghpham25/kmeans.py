'''kmeans.py
Performs K-Means clustering
Giang Pham
CS 252: Mathematical Data Analysis Visualization
Spring 2023
'''
import numpy as np
import matplotlib.pyplot as plt
from palettable import cartocolors
import random


class KMeans:
    def __init__(self, data=None):
        '''KMeans constructor

        (Should not require any changes)

        Parameters:
        -----------
        data: ndarray. shape=(num_samps, num_features)
        '''

        # k: int. Number of clusters
        self.k = None
        # centroids: ndarray. shape=(k, self.num_features)
        #   k cluster centers
        self.centroids = None
        # data_centroid_labels: ndarray of ints. shape=(self.num_samps,)
        #   Holds index of the assigned cluster of each data sample
        self.data_centroid_labels = None

        # inertia: float.
        #   Mean squared distance between each data sample and its assigned (nearest) centroid
        self.inertia = None

        # data: ndarray. shape=(num_samps, num_features)
        self.data = data
        # num_samps: int. Number of samples in the dataset
        self.num_samps = None
        # num_features: int. Number of features (variables) in the dataset
        self.num_features = None
        if data is not None:
            self.num_samps, self.num_features = data.shape
            
    def set_data(self, data):
        '''Replaces data instance variable with `data`.

        Reminder: Make sure to update the number of data samples and features!

        Parameters:
        -----------
        data: ndarray. shape=(num_samps, num_features)
        '''
        self.data = data
        self.num_samps, self.num_features = data.shape

    def get_data(self):
        '''Get a COPY of the data

        Returns:
        -----------
        ndarray. shape=(num_samps, num_features). COPY of the data
        '''
        return np.copy(self.data)

    def get_centroids(self):
        '''Get the K-means centroids

        (Should not require any changes)

        Returns:
        -----------
        ndarray. shape=(k, self.num_features).
        '''
        return self.centroids

    def get_data_centroid_labels(self):
        '''Get the data-to-cluster assignments

        (Should not require any changes)

        Returns:
        -----------
        ndarray of ints. shape=(self.num_samps,)
        '''
        return self.data_centroid_labels

    def dist_pt_to_pt(self, pt_1, pt_2):
        '''Compute the Euclidean distance between data samples `pt_1` and `pt_2`

        Parameters:
        -----------
        pt_1: ndarray. shape=(num_features,)
        pt_2: ndarray. shape=(num_features,)

        Returns:
        -----------
        float. Euclidean distance between `pt_1` and `pt_2`.

        NOTE: Implement without any for loops (you will thank yourself later since you will wait
        only a small fraction of the time for your code to stop running)
        '''
        return np.sqrt(np.sum(np.square(pt_1-pt_2)))

    def dist_pt_to_centroids(self, pt, centroids):
        '''Compute the Euclidean distance between data sample `pt` and and all the cluster centroids
        self.centroids

        Parameters:
        -----------
        pt: ndarray. shape=(num_features,)
        centroids: ndarray. shape=(C, num_features)
            C centroids, where C is an int.

        Returns:
        
        -----------
        ndarray. shape=(C,).
            distance between pt and each of the C centroids in `centroids`.

        NOTE: Implement without any for loops (you will thank yourself later since you will wait
        only a small fraction of the time for your code to stop running)
        '''

        return np.sqrt(np.sum(np.square((centroids - pt)), axis = 1))

    def initialize(self, k):
        '''Initializes K-means by setting the initial centroids (means) to K unique randomly
        selected data samples

        Parameters:
        -----------
        k: int. Number of clusters

        Returns:
        -----------
        ndarray. shape=(k, self.num_features). Initial centroids for the k clusters.

        NOTE: Can be implemented without any for loops
        '''

        samps = np.arange(self.num_samps)
        random_ks = np.random.choice(samps, k, replace=False)
        self.k = k
        return self.data[random_ks, :]

    def initialize_plusplus(self, k):
        '''Initializes K-means by setting the initial centroids (means) according to the K-means++
        algorithm

        Parameters:
        -----------
        k: int. Number of clusters

        Returns:
        -----------
        ndarray. shape=(k, self.num_features). Initial centroids for the k clusters.

        TODO:
        - Set initial centroid (i = 0) to a random data sample.
        - To pick the i-th centroid (i > 0)
            - Compute the distance between all data samples and i-1 centroids already initialized.
            - Create the distance-based probability distribution (see notebook for equation).
            - Select the i-th centroid by randomly choosing a data sample according to the probability
            distribution.
        '''
        self.k = k 
        samps = np.arange(self.num_samps)
        c1_index = np.random.choice(samps, 1 , replace = False)
        centroids_list = []
        centroids_list.append(self.data[c1_index])
        for i in range(k-1): 
            prob_nums = []
            prob_enum = 0
            for samp in self.data: 
                prob_num = np.square(np.min(self.dist_pt_to_centroids(samp, np.array(centroids_list))))
                prob_enum += prob_num
                prob_nums.append(prob_num)
            prob_nums = np.array(prob_nums)  
            prob_list = prob_nums/prob_enum
            next_centroid_index = np.random.choice(samps, 1, replace=False, p = np.array(prob_list))
            centroids_list.append(self.data[next_centroid_index])
        return np.array(centroids_list)


    def cluster(self, k=2, tol=1e-2, max_iter=1000, verbose=False, init_method = "random"):
        '''Performs K-means clustering on the data

        Parameters:
        -----------
        k: int. Number of clusters
        tol: float. Terminate K-means if the (absolute value of) the difference between all
        the centroid values from the previous and current time step < `tol`.
        max_iter: int. Make sure that K-means does not run more than `max_iter` iterations.
        verbose: boolean. Print out debug information if set to True.

        Returns:
        -----------
        self.inertia. float. Mean squared distance between each data sample and its cluster mean
        int. Number of iterations that K-means was run for

        TODO:
        - Initialize K-means variables
        - Do K-means as long as the max number of iterations is not met AND the absolute value of the
        difference between the previous and current centroid values is > `tol`
        - Set instance variables based on computed values.
        (All instance variables defined in constructor should be populated with meaningful values)
        - Print out total number of iterations K-means ran for
        '''
        if init_method == "kmeans++": 
            centroids = self.initialize_plusplus(k)
        else: 
            centroids = self.initialize(k)
        iters = 0
        diff = 100000
        labels = self.data_centroid_labels

        while (iters < max_iter) and (abs(diff) > tol):
            labels = self.update_labels(centroids)
            centroids, diff = self.update_centroids(k, labels, centroids)
            diff = np.max(diff)
            iters += 1

        self.data_centroid_labels = labels
        self.centroids = centroids

        inertia = self.compute_inertia()
        self.inertia = inertia
        # print(f"Total num iterations: {iters}") #uncomment this when neccessary 
        return self.inertia, iters

    def cluster_batch(self, k=2, n_iter=1, verbose=False, init_method = 'random'):
        '''Run K-means multiple times, each time with different initial conditions.
        Keeps track of K-means instance that generates lowest inertia. Sets the following instance
        variables based on the best K-mean run:
        - self.centroids
        - self.data_centroid_labels
        - self.inertia

        Parameters:
        -----------
        k: int. Number of clusters
        n_iter: int. Number of times to run K-means with the designated `k` value.
        verbose: boolean. Print out debug information if set to True.
        '''
        lowest_in = 10000000
        lowest_centroid = []
        lowest_label = []
        numints = []
        
        #loop for n iter times 
        for i in range(n_iter): 
            inertia, numint = self.cluster(k = k, init_method=init_method)
            if inertia < lowest_in: 
                lowest_in = inertia
                lowest_centroid = self.centroids
                lowest_label = self.data_centroid_labels
            numints.append(numint)
        self.centroids = np.array(lowest_centroid)
        self.data_centroid_labels = np.array(lowest_label)
        self.inertia = lowest_in
        return np.mean(np.array(numints))

    def update_labels(self, centroids):
        '''Assigns each data sample to the nearest centroid

        Parameters:
        -----------
        centroids: ndarray. shape=(k, self.num_features). Current centroids for the k clusters.

        Returns:
        -----------
        ndarray of ints. shape=(self.num_samps,). Holds index of the assigned cluster of each data
            sample. These should be ints (pay attention to/cast your dtypes accordingly).

        Example: If we have 3 clusters and we compute distances to data sample i: [0.1, 0.5, 0.05]
        labels[i] is 2. The entire labels array may look something like this: [0, 2, 1, 1, 0, ...]
        '''
        labels = []
        for i in range(self.num_samps):
            samp = self.data[i, :]
            dists = self.dist_pt_to_centroids(samp, centroids)
            index = list(dists).index(np.min(dists))
            labels.append(index)
        self.data_centroid_labels = np.array(labels)
        return self.data_centroid_labels

    def update_centroids(self, k, data_centroid_labels, prev_centroids):
        '''Computes each of the K centroids (means) based on the data assigned to each cluster

        Parameters:
        -----------
        k: int. Number of clusters
        data_centroid_labels. ndarray of ints. shape=(self.num_samps,)
            Holds index of the assigned cluster of each data sample
        prev_centroids. ndarray. shape=(k, self.num_features)
            Holds centroids for each cluster computed on the PREVIOUS time step

        Returns:
        -----------
        new_centroids. ndarray. shape=(k, self.num_features).
            Centroids for each cluster computed on the CURRENT time step
        centroid_diff. ndarray. shape=(k, self.num_features).
            Difference between current and previous centroid values

        NOTE: Your implementation should handle the case when there are no samples assigned to a cluster —
        i.e. `data_centroid_labels` does not have a valid cluster index in it at all.
            For example, if `k`=3 and data_centroid_labels = [0, 1, 0, 0, 1], there are no samples assigned to cluster 2.
        In the case of each cluster without samples assigned to it, you should assign make its centroid a data sample
        randomly selected from the dataset.
        '''

        means = []  # shape of ws: (k, ...)

        rangek = np.arange(k)
        for i in rangek:
            if i not in data_centroid_labels:
                randomind = np.random.choice(rangek, 1)
                random_centroid = self.data[randomind]
                mean = np.mean(random_centroid, axis=0)
                means.append(mean)
            else:
                # shape: (number of samples in cluster i, )
                wi = self.data[data_centroid_labels == i]
                mean = np.mean(wi, axis=0)
                means.append(mean)

        means = np.array(means)
        self.centroids = means
        centroid_diff = means - prev_centroids
        return self.centroids, centroid_diff

    def compute_inertia(self):
        '''Mean squared distance between every data sample and its assigned (nearest) centroid

        Returns:
        -----------
        float. The average squared distance between every data sample and its assigned cluster centroid.
        '''
        mse = 0
        for i in range(self.num_samps):
            samp = self.data[i]
            dist2 = np.square(self.dist_pt_to_pt(
                samp, self.centroids[self.data_centroid_labels[i]]))
            mse += dist2
        return mse/self.num_samps

    def plot_clusters(self, xtitle = ",", ytitle = "", title = ""):
        '''Creates a scatter plot of the data color-coded by cluster assignment.

        TODO:
        - Plot samples belonging to a cluster with the same color.
        - Plot the centroids in black with a different plot marker.
        - The default scatter plot color palette produces colors that may be difficult to discern
        (especially for those who are colorblind). Make sure you change your colors to be clearly
        differentiable.
            You should use a palette Colorbrewer2 palette. Pick one with a generous
            number of colors so that you don't run out if k is large (e.g. 10).
        '''
        fig, ax = plt.subplots()
        color = cartocolors.qualitative.Prism_10.mpl_colors
        # plotting data
        for i in range(self.k):
            wi = self.data[self.data_centroid_labels == i]
            ax.plot(wi[:, 0], wi[:, 1], 'o', alpha=0.5, label=f'cluster{i}', color = color[i]) 

        # plotting centroids
        ax.plot(self.centroids[:, 0],
                self.centroids[:, 1], 'k*', label='centroids')
        ax.set_xlabel(xtitle)
        ax.set_ylabel(ytitle)
        ax.set_title(title)

        fig.tight_layout()

    def elbow_plot(self, max_k, n_iter = 1):
        '''Makes an elbow plot: cluster number (k) on x axis, inertia on y axis.

        Parameters:
        -----------
        max_k: int. Run k-means with k=1,2,...,max_k.

        TODO:
        - Run k-means with k=1,2,...,max_k, record the inertia.
        - Make the plot with appropriate x label, and y label, x tick marks.
        '''
        x = np.arange(1, max_k + 1)
        y = []

        for i in range(1,max_k+1): 
            self.cluster_batch(k = i, n_iter=n_iter)
            y.append(self.inertia)
        y = np.array(y)
        
        fig, ax = plt.subplots()
        ax.plot(x,y)
        ax.set_xlabel("K clusters")
        ax.set_ylabel("intertia")
        ax.set_xticks(x)
        fig.tight_layout()

    def replace_color_with_centroid(self):
        '''Replace each RGB pixel in self.data (flattened image) with the closest centroid value.
        Used with image compression after K-means is run on the image vector.

        Parameters:
        -----------
        None

        Returns:
        -----------
        None
        '''
        for i in range(self.k): 
            self.data[self.data_centroid_labels == i] = self.centroids[i]         